# php-adb
Simple wrapper of Android Debug Bridge for PHP.
